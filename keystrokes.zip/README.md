# keystrokes
Software feito em python para ficar pressionando uma determinada tecla dentro de um game no sistema window.

# Executar o software
Para executar o software é simples, entre no diretório que você fez o clone e utilize o comando:

```
python3 keystrokes.py
```

Quando você estiver dentro do jogo, pressione a tecla ‘ENTER’ durante um tempo que irá começar utilizar a key que você selecionou, para desligar o pressionamento da key, segure ‘ENTER’ durante algum tempo também.

# Dependências
Lembrando que você precisa conter em sua máquina as seguintes bibliotecas:

```Instalar as dependências
pip3 install pynput
pip3 install keyboard
```

